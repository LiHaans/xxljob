#!/bin/bash

# ==== 配置 ====
CPU_THRESHOLD=90
MEM_THRESHOLD=90
LOG_FILE="/data/lh/sh/resource_alert_v2.log"    # 请确保该路径可写
CHECK_INTERVAL=30  # 秒
MAX_LOG_SIZE=$((100 * 1024 * 1024))  # 100MB

PID_FILE="/tmp/resource_monitor.pid"
LOCK_FILE="/tmp/resource_monitor.lock"

# ==== 环境准备 ====

# 创建日志目录及文件
LOG_DIR=$(dirname "$LOG_FILE")
mkdir -p "$LOG_DIR"
touch "$LOG_FILE" || { echo "❌ 无法写入日志文件 $LOG_FILE"; exit 1; }

# 写 PID 文件
echo $$ > "$PID_FILE"

# 日志写函数，加锁避免并发写乱序
log() {
    local msg="$1"
    (
        flock -x 200
        echo "[$(date '+%F %T')] $msg"
    ) 200>>"$LOCK_FILE" >> "$LOG_FILE"
}

# 日志轮转，避免日志过大
rotate_log() {
    if [ -f "$LOG_FILE" ]; then
        local size=$(stat -c%s "$LOG_FILE")
        if [ "$size" -gt "$MAX_LOG_SIZE" ]; then
            mv "$LOG_FILE" "${LOG_FILE}.old"
            touch "$LOG_FILE"
            log "🔄 日志轮转：旧日志移至 ${LOG_FILE}.old"
        fi
    fi
}

# 简单报警示例（可改成发邮件、微信等）
alert() {
    # 示例：
    # echo "Resource alert: $1" | mail -s "Resource Alert" your@email.com
    # curl -X POST -d '{"msg":"'$1'"}' https://your-webhook-url
    echo "🔔 报警触发: $1"
}

# ==== 主程序 ====

log "▶️ Resource Monitor 启动，阈值 CPU=${CPU_THRESHOLD}% MEM=${MEM_THRESHOLD}%，检查间隔 ${CHECK_INTERVAL}s"

while true; do
    rotate_log

    # CPU使用率（整数）
    CPU_IDLE=$(top -bn1 | grep "Cpu(s)" | awk -F'id,' '{ split($1, vs, ","); for (i in vs) { if (vs[i] ~ /id/) { gsub(/[^0-9.]/, "", vs[i]); print int(vs[i]) } } }')
    CPU_USAGE=$((100 - CPU_IDLE))

    # 内存使用率（整数）
    MEM_TOTAL=$(free | awk '/Mem:/ {print $2}')
    MEM_USED=$(free | awk '/Mem:/ {print $3}')
    MEM_USAGE=$(( MEM_USED * 100 / MEM_TOTAL ))

    echo "CPU_USAGE=$CPU_USAGE"
    echo "MEM_USAGE=$MEM_USAGE"

    if [ "$CPU_USAGE" -gt "$CPU_THRESHOLD" ] || [ "$MEM_USAGE" -gt "$MEM_THRESHOLD" ]; then
     log "⚠️ CPU=${CPU_USAGE}% / MEM=${MEM_USAGE}% 超出阈值，记录资源使用情况..."

     {
         echo ">> Load Average:"
         uptime | awk -F'load average:' '{print $2}'

         echo ">> 当前 free -m:"
         free -m

         echo ">> Top 10 Memory Consumers:"
         ps aux --sort=-%mem | head -n 11

         echo ">> Top 10 CPU Consumers:"
         ps aux --sort=-%cpu | head -n 11

         echo ">> 当前 Yarn 相关进程（如果有）："
         ps -ef | grep -i container | grep -v grep
 
         echo "------------------------------------------"
     } | while IFS= read -r line; do log "    $line"; done
    fi


    sleep "$CHECK_INTERVAL"
done

