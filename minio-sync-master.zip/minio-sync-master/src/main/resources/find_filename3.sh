#!/bin/bash

# 递归查找目录下的所有文件
find_files() {
  # 使用 ls -1f --ignore='.*' 获取非隐藏文件和目录，并过滤掉 part.* 格式的文件
  ls -1f --ignore='.*' "$1" | grep -v '^part\.' | while IFS= read -r item; do
    full_path="$1/$item"  # 拼接完整路径

    # 判断文件是否为 xl.meta 文件
    if [[ "$item" == "xl.meta" ]]; then
      # 如果是 xl.meta 文件，输出它的父目录路径
      echo "$(dirname "$full_path")"

    # 如果是目录，递归查询
    elif [[ -d "$full_path" ]]; then
      find_files "$full_path"
    fi
  done
}

# 获取要查询的目录路径
directory_to_search="$1"
if [ -z "$directory_to_search" ]; then
  echo "Please provide a directory path."
  exit 1
fi

# 调用递归函数
find_files "$directory_to_search"
