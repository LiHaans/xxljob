#!/bin/bash

# 递归查找目录下的所有文件
find_files() {
  # 遍历目录中的所有非隐藏项，使用 ls -1 --ignore='.*' 排除隐藏文件
  # 使用 while 循环逐行读取，处理文件名中有空格的情况
  ls -1f --ignore='.*' "$1" | while IFS= read -r item; do
    item="$1/$item"  # 拼接完整路径

    # 判断文件名是否包含 "."
    if [[ "$item" == *.* ]]; then
      # 如果包含 ".", 认为是文件，打印文件路径
      echo "$item"
    elif [[ ! "$item" == *.* ]]; then
      # 如果文件名不包含 ".", 认为是目录，递归查询子目录
      find_files "$item"
    fi
  done
}

# 获取要查询的目录路径
directory_to_search="$1"
if [ -z "$directory_to_search" ]; then
  echo "Please provide a directory path."
  exit 1
fi

# 调用递归函数
find_files "$directory_to_search"