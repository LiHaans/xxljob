package cn.golaxy.sync;

import io.minio.MinioClient;
import io.minio.errors.MinioException;
import io.minio.GetObjectArgs;
import io.minio.PutObjectArgs;

import java.io.*;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.concurrent.*;

public class MinioSync {

    public static void main(String[] args) throws Exception {
        // 加载配置文件
        Properties properties = new Properties();
        try (InputStream input = new FileInputStream("config.properties")) {
            properties.load(input);
        }

        // MinIO 配置
        String sourceEndpoint = properties.getProperty("source.endpoint");
        String sourceBucket = properties.getProperty("source.bucket");
        String sourceAccessKey = properties.getProperty("source.accessKey");
        String sourceSecretKey = properties.getProperty("source.secretKey");

        String targetEndpoint = properties.getProperty("target.endpoint");
        String targetBucket = properties.getProperty("target.bucket");
        String targetAccessKey = properties.getProperty("target.accessKey");
        String targetSecretKey = properties.getProperty("target.secretKey");

        // 线程池配置
        int corePoolSize = Integer.parseInt(properties.getProperty("thread.corePoolSize"));
        int maxPoolSize = Integer.parseInt(properties.getProperty("thread.maxPoolSize"));
        int queueCapacity = Integer.parseInt(properties.getProperty("thread.queueCapacity"));
        long keepAliveTime = Long.parseLong(properties.getProperty("thread.keepAliveTime"));

        // 任务配置
        int batchSize = Integer.parseInt(properties.getProperty("batch.size"));
        String filePath = properties.getProperty("file.path");

        // 输出文件路径配置
        String successLogPath = properties.getProperty("success.log.path", "sync-success.log");

        // 自定义线程池
        ThreadPoolExecutor executorService = new ThreadPoolExecutor(
                corePoolSize,
                maxPoolSize,
                keepAliveTime,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(queueCapacity),
                new ThreadPoolExecutor.CallerRunsPolicy()
        );

        MinioClient sourceClient = MinioClient.builder()
                .endpoint(sourceEndpoint)
                .credentials(sourceAccessKey, sourceSecretKey)
                .build();

        MinioClient targetClient = MinioClient.builder()
                .endpoint(targetEndpoint)
                .credentials(targetAccessKey, targetSecretKey)
                .build();

        // 用于记录成功同步的文件路径
        Set<String> successfulFiles = Collections.synchronizedSet(new HashSet<>());

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            List<String> batch = new ArrayList<>();
            String line;

            while ((line = reader.readLine()) != null) {
                batch.add(line);
                if (batch.size() == batchSize) {
                    List<String> batchToProcess = new ArrayList<>(batch);
                    executorService.submit(() -> {
                        try {
                            processBatch(batchToProcess, sourceClient, targetClient, sourceBucket, targetBucket, successfulFiles);
                        } catch (NoSuchAlgorithmException e) {
                            e.printStackTrace();
                        } catch (InvalidKeyException e) {
                            e.printStackTrace();
                        }
                    });
                    batch.clear();
                }
            }

            // 处理剩余的文件
            if (!batch.isEmpty()) {
                executorService.submit(() -> {
                    try {
                        processBatch(batch, sourceClient, targetClient, sourceBucket, targetBucket, successfulFiles);
                    } catch (NoSuchAlgorithmException e) {
                        e.printStackTrace();
                    } catch (InvalidKeyException e) {
                        e.printStackTrace();
                    }
                });
            }
        }

        executorService.shutdown();
        executorService.awaitTermination(1, TimeUnit.HOURS);

        // 记录成功同步的文件路径到文件
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(successLogPath))) {
            for (String successFilePath : successfulFiles) {
                writer.write(successFilePath);
                writer.newLine();
            }
        }
    }

    private static void processBatch(List<String> batch, MinioClient sourceClient, MinioClient targetClient, String sourceBucket, String targetBucket, Set<String> successfulFiles) throws NoSuchAlgorithmException, InvalidKeyException {
        for (String filePath : batch) {
            try (InputStream inputStream = sourceClient.getObject(GetObjectArgs.builder()
                    .bucket(sourceBucket)
                    .object(filePath)
                    .build())) {

                targetClient.putObject(PutObjectArgs.builder()
                        .bucket(targetBucket)
                        .object(filePath)
                        .stream(inputStream, inputStream.available(), -1)
                        .build());

                // 记录成功同步的文件路径
                successfulFiles.add(filePath);
                System.out.println("File synced: " + filePath);
            } catch (MinioException | IOException e) {
                System.err.println("Error syncing file: " + filePath);
                e.printStackTrace();
            }
        }
    }
}
