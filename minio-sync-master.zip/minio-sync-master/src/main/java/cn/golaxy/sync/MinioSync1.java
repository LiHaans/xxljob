package cn.golaxy.sync;

import io.minio.MinioClient;

import io.minio.GetObjectArgs;
import io.minio.PutObjectArgs;
import io.minio.StatObjectArgs;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.nio.file.Files;

@Slf4j
public class MinioSync1 {
    private static final AtomicInteger skippedFilesCount = new AtomicInteger(0);
    private static final AtomicInteger totalFilesSynced = new AtomicInteger(0);
    private static final AtomicLong totalSize = new AtomicLong(0);
    private static final AtomicLong failSize = new AtomicLong(0);
    private static final AtomicLong totalFiles = new AtomicLong(0);

    private final Config config;
    private final ExecutorService executorService;
    private final MinioClient sourceClient;
    private final MinioClient targetClient;
    private final long startTime = System.currentTimeMillis();

    private final ConcurrentLinkedQueue<String> successQueue = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<String> failQueue = new ConcurrentLinkedQueue<>();

    private final int threadCount;

    private final SystemMetrics systemMetrics = new SystemMetrics();

    public MinioSync1(String configPath) throws IOException {
        this.config = new Config(configPath);
        int availableProcessors = Runtime.getRuntime().availableProcessors();
        this.threadCount = Math.max(availableProcessors * 2, config.getInt("thread.core.pool.size"));
        
        this.executorService = new ThreadPoolExecutor(
            threadCount,
            threadCount * 2,
            60L,
            TimeUnit.SECONDS,
            new LinkedBlockingQueue<>(config.getInt("queue.size")),
            new ThreadFactory() {
                private final AtomicInteger counter = new AtomicInteger(1);
                @Override
                public Thread newThread(Runnable r) {
                    Thread thread = new Thread(r);
                    thread.setName("minio-sync-thread-" + counter.getAndIncrement());
                    thread.setPriority(Thread.MAX_PRIORITY);
                    return thread;
                }
            },
            new ThreadPoolExecutor.CallerRunsPolicy()
        );
        
        this.sourceClient = createMinioClient(true);
        this.targetClient = createMinioClient(false);
    }

    private MinioClient createMinioClient(boolean isSource) {
        String prefix = isSource ? "source" : "target";
        return MinioClient.builder()
                .endpoint(config.getString(prefix + ".endpoint"))
                .credentials(
                        config.getString(prefix + ".accessKey"),
                        config.getString(prefix + ".secretKey")
                )
                .httpClient(createHttpClient())
                .build();
    }

    private OkHttpClient createHttpClient() {
        return new OkHttpClient.Builder()
                .connectTimeout(config.getInt("http.connect.timeout.seconds"), TimeUnit.SECONDS)
                .writeTimeout(config.getInt("http.write.timeout.seconds"), TimeUnit.SECONDS)
                .readTimeout(config.getInt("http.read.timeout.seconds"), TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .connectionPool(new ConnectionPool(
                    threadCount * 2,
                    config.getInt("http.keep.alive.minutes"),
                    TimeUnit.MINUTES))
                .build();
    }

    public void startSync() throws Exception {
        // 检查配置文件
        log.info("开始同步，配置信息：");
        log.info("源MinIO: {} -> {}", config.getString("source.endpoint"), config.getString("source.bucket"));
        log.info("目标MinIO: {} -> {}", config.getString("target.endpoint"), config.getString("target.bucket"));
        log.info("基础路径: {}", config.getString("base.path"));
        log.info("文件路径: {}", config.getString("file.path"));
        
        // 检查文件是否存在
        File file = new File(config.getString("file.path"));
        if (!file.exists()) {
            throw new FileNotFoundException("文件不存在: " + config.getString("file.path"));
        }
        log.info("文件大小: {} 字节", file.length());

        // 启动进度报告
        ScheduledExecutorService progressReporter = Executors.newSingleThreadScheduledExecutor();
        progressReporter.scheduleAtFixedRate(
                this::printProgress,
                0,
                config.getInt("progress.report.interval.seconds"),
                TimeUnit.SECONDS
        );

        // 预热连接
        warmupConnections();

        // 启动日志写入服务
        batchWriteLogs();

        // 创建阻塞队列用于存储文件路径
        BlockingQueue<String> pathQueue = new LinkedBlockingQueue<>(config.getInt("queue.size"));

        // 预加载线程
        CompletableFuture<Void> prefetchFuture = CompletableFuture.runAsync(() -> {
            readFileWithNIO(config.getString("file.path"), pathQueue,
                    config.getInt("file.skip.lines", 0));
        });

        // 创建多个处理线程
        List<CompletableFuture<Void>> processFutures = new ArrayList<>();
        for (int i = 0; i < threadCount; i++) {
            processFutures.add(CompletableFuture.runAsync(() -> {
                try {
                    while (true) {
                        String path = pathQueue.take();
                        if ("EOF".equals(path)) {
                            log.info("线程 {} 处理完成", Thread.currentThread().getName());
                            break;
                        }
                        processPath(path);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }, executorService));
        }

        // 等待所有任务完成
        CompletableFuture<Void> allFutures = CompletableFuture.allOf(
                CompletableFuture.allOf(processFutures.toArray(new CompletableFuture[0])),
                prefetchFuture
        );

        allFutures.join();
        executorService.shutdown();
        executorService.awaitTermination(1, TimeUnit.HOURS);
        progressReporter.shutdown();

        printFinalStats(System.currentTimeMillis() - startTime);
    }

    private void readFileWithNIO(String filePath, BlockingQueue<String> pathQueue, int skipLines) {
        try {
            // 先统计总行数
            long totalLines = countTotalLines(filePath);
            totalFiles.set(totalLines);
            log.info("文件总行数: {}", totalLines);

            // 使用BufferedReader读取文件
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                int linesSkipped = 0;
                int validLines = 0;
                
                while ((line = reader.readLine()) != null) {
                    if (linesSkipped < skipLines) {
                        linesSkipped++;
                        continue;
                    }
                    
                    line = line.trim();
                    if (!line.isEmpty()) {
                        pathQueue.put(line);
                        validLines++;
                        if (validLines % 10000 == 0) {
                            log.info("已读取 {} 行", validLines);
                        }
                    }
                }
                
                log.info("文件读取完成，有效行数: {}", validLines);
                // 添加结束标记
                pathQueue.put("EOF");
            }
        } catch (Exception e) {
            log.error("读取文件失败", e);
        }
    }

    private long countTotalLines(String filePath) throws IOException {
        try {
            // 使用wc -l命令统计行数
            Process process = Runtime.getRuntime().exec("wc -l " + filePath);
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line = reader.readLine();
            if (line != null) {
                // 解析wc命令输出，格式为：行数 文件名
                String[] parts = line.trim().split("\\s+");
                if (parts.length > 0) {
                    return Long.parseLong(parts[0]);
                }
            }
            process.waitFor();
        } catch (Exception e) {
            log.error("使用wc命令统计行数失败", e);
        }
        return 0;
    }

    private void processChunk(ByteBuffer buffer, BlockingQueue<String> pathQueue, int skipLines) {
        byte[] lineBytes = new byte[config.getInt("line.buffer.size")];
        int linePos = 0;
        int linesSkipped = 0;
        
        while (buffer.hasRemaining()) {
            byte b = buffer.get();
            if (b == '\n') {
                if (linesSkipped >= skipLines && linePos > 0) {
                    String line = new String(lineBytes, 0, linePos).trim();
                    if (!line.isEmpty()) {
                        try {
                            pathQueue.put(line);
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                            break;
                        }
                    }
                } else {
                    linesSkipped++;
                }
                linePos = 0;
            } else if (linePos < lineBytes.length) {
                lineBytes[linePos++] = b;
            }
        }
    }

    private void processPath(String filePath) {
        try {
            String processedPath = processPath(filePath, config.getString("base.path"));
            
            // 使用CompletableFuture异步处理
            CompletableFuture.runAsync(() -> {
                try {
                    StatObjectArgs statObjectArgs = StatObjectArgs.builder()
                        .bucket(config.getString("source.bucket"))
                        .object(processedPath)
                        .build();
                    long fileSize = sourceClient.statObject(statObjectArgs).size();

                    boolean fileExists = checkFileExists(targetClient,
                            config.getString("target.bucket"), processedPath, fileSize);

                    if (!fileExists) {
                        try (InputStream inputStream = sourceClient.getObject(GetObjectArgs.builder()
                                .bucket(config.getString("source.bucket"))
                                .object(processedPath)
                                .build());
                             BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream, 8192)) {
                            
                            targetClient.putObject(PutObjectArgs.builder()
                                    .bucket(config.getString("target.bucket"))
                                    .object(processedPath)
                                    .stream(bufferedInputStream, fileSize, -1)
                                    .build());

                            totalFilesSynced.incrementAndGet();
                            totalSize.addAndGet(fileSize);
                            successQueue.add(filePath);
                            log.debug("同步文件成功: {}", filePath);
                        }
                    } else {
                        skippedFilesCount.incrementAndGet();
                        totalSize.addAndGet(fileSize);
                        successQueue.add(filePath);
                        log.debug("跳过已存在文件: {}", filePath);
                    }
                } catch (Exception e) {
                    log.error("处理文件失败: " + filePath, e);
                    failSize.incrementAndGet();
                    failQueue.add(filePath);
                }
            }, executorService);
        } catch (Exception e) {
            log.error("处理文件失败: " + filePath, e);
            failSize.incrementAndGet();
            failQueue.add(filePath);
        }
    }

    private void batchWriteLogs() {
        ScheduledExecutorService logWriter = Executors.newSingleThreadScheduledExecutor();
        logWriter.scheduleAtFixedRate(() -> {
            List<String> successBatch = new ArrayList<>();
            for (int i = 0; i < 1000 && !successQueue.isEmpty(); i++) {
                String path = successQueue.poll();
                if (path != null) {
                    successBatch.add(path);
                }
            }
            if (!successBatch.isEmpty()) {
                writeToFile(successBatch, config.getString("success.log.path"));
            }

            List<String> failBatch = new ArrayList<>();
            for (int i = 0; i < 1000 && !failQueue.isEmpty(); i++) {
                String path = failQueue.poll();
                if (path != null) {
                    failBatch.add(path);
                }
            }
            if (!failBatch.isEmpty()) {
                writeToFile(failBatch, config.getString("fail.log.path"));
            }
        }, 0, 1, TimeUnit.SECONDS);
    }

    private void printProgress() {
        int syncedFiles = totalFilesSynced.get();
        int skippedFiles = skippedFilesCount.get();
        int failedFiles = (int)failSize.get();
        int totalProcessed = syncedFiles + skippedFiles + failedFiles;
        long total = totalFiles.get();
        long remaining = Math.max(0, total - totalProcessed);
        long runningTime = System.currentTimeMillis() - startTime;

        SystemMetricsSnapshot metrics = systemMetrics.getMetrics();

        String estimatedTime = "N/A";
        if (metrics.fileRate > 0) {
            long estimatedSeconds = (long) (remaining / metrics.fileRate);
            estimatedTime = convertMillisToTime(estimatedSeconds * 1000);
        }

        double progressPercent = total > 0 ? (totalProcessed * 100.0) / total : 0;

        log.info("\n========== 同步进度 ==========\n" +
                String.format("进度: %.2f%% [%d/%d]\n", 
                    progressPercent, totalProcessed, total) +
                String.format("详情: 同步: %d, 跳过: %d, 失败: %d\n", 
                    syncedFiles, skippedFiles, failedFiles) +
                String.format("数据量: %s\n", 
                    formatFileSize(totalSize.get())) +
                String.format("速率: %s/秒, %.1f个/秒\n",
                    formatFileSize((long)metrics.byteRate), metrics.fileRate) +
                String.format("时间: 已运行 %s, 预计剩余 %s\n",
                    convertMillisToTime(runningTime), estimatedTime) +
                "============================");
    }

    private void printFinalStats(long totalTime) {
        int syncedFiles = totalFilesSynced.get();
        int skippedFiles = skippedFilesCount.get();
        int totalProcessed = syncedFiles + skippedFiles;

        log.info("\n========== 同步完成 ==========\n" +
                String.format("总文件数: %d (同步: %d, 跳过: %d, 失败: %d)\n", 
                    totalProcessed, syncedFiles, skippedFiles, failSize.get()) +
                String.format("总数据量: %s\n", 
                    formatFileSize(totalSize.get())) +
                String.format("总耗时: %s\n", 
                    convertMillisToTime(totalTime)) +
                "============================");
    }

    private void writeToFile(List<String> fileNames, String logFilePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(logFilePath, true))) {
            for (String fileName : fileNames) {
                writer.write(fileName);
                writer.newLine();
            }
        } catch (IOException e) {
            log.error("写入日志文件失败", e);
        }
    }

    private boolean checkFileExists(MinioClient client, String bucket, String objectName, long expectedSize) {
        try {
            StatObjectArgs statObjectArgs = StatObjectArgs.builder()
                    .bucket(bucket)
                    .object(objectName)
                    .build();
            long remoteFileSize = client.statObject(statObjectArgs).size();
            return remoteFileSize == expectedSize;
        } catch (Exception e) {
            return false;
        }
    }

    private String processPath(String fullPath, String basePath) {
        if (StringUtils.isEmpty(basePath)) {
            return fullPath;
        }
        if (fullPath.startsWith(basePath)) {
            return fullPath.substring(basePath.length());
        }
        return fullPath;
    }

    private static String formatFileSize(long size) {
        if (size <= 0) return "0 B";
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int unitIndex = 0;
        double fileSize = size;
        while (fileSize >= 1024 && unitIndex < units.length - 1) {
            fileSize /= 1024;
            unitIndex++;
        }
        return String.format("%.2f %s", fileSize, units[unitIndex]);
    }

    private static String convertMillisToTime(long millis) {
        long seconds = millis / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        hours = hours % 24;
        minutes = minutes % 60;
        seconds = seconds % 60;
        return String.format("%d天 %d小时 %d分钟 %d秒", days, hours, minutes, seconds);
    }

    public static void main(String[] args) {
        try {
            MinioSync1 sync = new MinioSync1("config.properties");
            sync.startSync();
        } catch (Exception e) {
            log.error("同步失败", e);
            System.exit(1);
        }
    }

    private static class Config {
        private final Properties properties;

        public Config(String configPath) throws IOException {
            properties = new Properties();
            try (InputStream input = new FileInputStream(configPath)) {
                properties.load(input);
            }
        }

        public String getString(String key) {
            return properties.getProperty(key);
        }

        public int getInt(String key) {
            return Integer.parseInt(properties.getProperty(key));
        }

        public int getInt(String key, int defaultValue) {
            String value = properties.getProperty(key);
            return value != null ? Integer.parseInt(value) : defaultValue;
        }
    }

    private void warmupConnections() {
        int warmupThreads = Math.min(
            config.getInt("warmup.thread.count"),
            threadCount
        );
        CountDownLatch latch = new CountDownLatch(warmupThreads);
        
        for (int i = 0; i < warmupThreads; i++) {
            executorService.submit(() -> {
                try {
                    sourceClient.listBuckets();
                    targetClient.listBuckets();
                    latch.countDown();
                } catch (Exception e) {
                    log.warn("预热连接失败", e);
                    latch.countDown();
                }
            });
        }
        
        try {
            latch.await(30, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static class SystemMetrics {
        private final OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
        private final Runtime runtime = Runtime.getRuntime();
        private long lastBytesRead = 0;
        private long lastBytesWritten = 0;
        private long lastTimestamp = System.currentTimeMillis();
        private double lastCpuTime = 0;
        private long lastProcessedFiles = 0;
        private long lastProcessedBytes = 0;

        public SystemMetricsSnapshot getMetrics() {
            long currentTime = System.currentTimeMillis();
            double timeDiffInSeconds = (currentTime - lastTimestamp) / 1000.0;

            int currentProcessedFiles = totalFilesSynced.get() + skippedFilesCount.get();
            long currentProcessedBytes = totalSize.get();

            double fileRate = (currentProcessedFiles - lastProcessedFiles) / timeDiffInSeconds;
            double byteRate = (currentProcessedBytes - lastProcessedBytes) / timeDiffInSeconds;

            double cpuUsage = 0;
            try {
                cpuUsage = getCpuUsage();
            } catch (Exception e) {
                log.warn("无法读取CPU使用率", e);
            }

            long totalMemory = runtime.totalMemory();
            long freeMemory = runtime.freeMemory();
            long usedMemory = totalMemory - freeMemory;
            double memoryUsage = ((double) usedMemory / totalMemory) * 100;

            long bytesRead = 0;
            long bytesWritten = 0;
            try {
                File procFile = new File("/proc/self/io");
                if (procFile.exists()) {
                    List<String> lines = Files.readAllLines(procFile.toPath());
                    for (String line : lines) {
                        if (line.startsWith("read_bytes:")) {
                            bytesRead = Long.parseLong(line.split("\\s+")[1]);
                        } else if (line.startsWith("write_bytes:")) {
                            bytesWritten = Long.parseLong(line.split("\\s+")[1]);
                        }
                    }
                }
            } catch (Exception e) {
                log.warn("无法读取IO统计信息", e);
            }

            double readRate = (bytesRead - lastBytesRead) / timeDiffInSeconds;
            double writeRate = (bytesWritten - lastBytesWritten) / timeDiffInSeconds;

            double networkRate = totalSize.get() / timeDiffInSeconds;

            lastProcessedFiles = currentProcessedFiles;
            lastProcessedBytes = currentProcessedBytes;
            lastTimestamp = currentTime;

            return new SystemMetricsSnapshot(
                cpuUsage,
                memoryUsage,
                readRate,
                writeRate,
                networkRate,
                fileRate,
                byteRate
            );
        }

        private double getCpuUsage() throws IOException {
            List<String> lines = Files.readAllLines(Paths.get("/proc/stat"));
            String cpuLine = lines.get(0);
            String[] cpuData = cpuLine.split("\\s+");
            
            long user = Long.parseLong(cpuData[1]);
            long nice = Long.parseLong(cpuData[2]);
            long system = Long.parseLong(cpuData[3]);
            long idle = Long.parseLong(cpuData[4]);
            long iowait = Long.parseLong(cpuData[5]);
            long irq = Long.parseLong(cpuData[6]);
            long softirq = Long.parseLong(cpuData[7]);
            
            double totalCpuTime = user + nice + system + idle + iowait + irq + softirq;
            double idleTime = idle + iowait;
            
            double cpuUsage = 0;
            if (lastCpuTime > 0) {
                double totalDiff = totalCpuTime - lastCpuTime;
                double idleDiff = idleTime - lastCpuTime;
                if (totalDiff > 0) {
                    cpuUsage = ((totalDiff - idleDiff) / totalDiff) * 100;
                }
            }
            
            lastCpuTime = totalCpuTime;
            return cpuUsage;
        }
    }

    private static class SystemMetricsSnapshot {
        final double cpuUsage;
        final double memoryUsage;
        final double diskReadRate;
        final double diskWriteRate;
        final double networkRate;
        final double fileRate;
        final double byteRate;

        SystemMetricsSnapshot(double cpuUsage, double memoryUsage, 
                double diskReadRate, double diskWriteRate, double networkRate,
                double fileRate, double byteRate) {
            this.cpuUsage = cpuUsage;
            this.memoryUsage = memoryUsage;
            this.diskReadRate = diskReadRate;
            this.diskWriteRate = diskWriteRate;
            this.networkRate = networkRate;
            this.fileRate = fileRate;
            this.byteRate = byteRate;
        }
    }
}