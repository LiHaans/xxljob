package cn.golaxy.sync;

import cn.golaxy.index.FileDataWarehouseIndex;
import cn.golaxy.service.ElasticsearchService;
import io.minio.*;
import io.minio.errors.MinioException;
import io.minio.messages.Item;
import org.elasticsearch.client.RestHighLevelClient;
import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;

import java.io.*;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class MinioSyncES {

    // 用于记录跳过的文件数量
    private static final AtomicInteger skippedFilesCount = new AtomicInteger(0);

    // 用于记录成功同步的文件数量和总文件大小
    private static final AtomicInteger totalFilesSynced = new AtomicInteger(0);
    private static final AtomicLong totalSize = new AtomicLong(0);

    public static void main(String[] args) throws Exception {
        // 加载配置文件
        Properties properties = new Properties();
        try (InputStream input = new FileInputStream("config.properties")) {
            properties.load(input);
        }

        // MinIO 配置
        String sourceEndpoint = properties.getProperty("source.endpoint");
        String sourceBucket = properties.getProperty("source.bucket");
        String sourceAccessKey = properties.getProperty("source.accessKey");
        String sourceSecretKey = properties.getProperty("source.secretKey");

        String targetEndpoint = properties.getProperty("target.endpoint");
        String targetBucket = properties.getProperty("target.bucket");
        String targetAccessKey = properties.getProperty("target.accessKey");
        String targetSecretKey = properties.getProperty("target.secretKey");

        // 线程池配置
        int corePoolSize = Integer.parseInt(properties.getProperty("thread.corePoolSize"));
        int maxPoolSize = Integer.parseInt(properties.getProperty("thread.maxPoolSize"));
        int queueCapacity = Integer.parseInt(properties.getProperty("thread.queueCapacity"));
        long keepAliveTime = Long.parseLong(properties.getProperty("thread.keepAliveTime"));

        // 任务配置
        int batchSize = Integer.parseInt(properties.getProperty("batch.size"));
        String filePath = properties.getProperty("file.path");

        // 输出文件路径配置
        String successLogPath = properties.getProperty("success.log.path", "sync-success.log");

        // 自定义线程池
        ThreadPoolExecutor executorService = new ThreadPoolExecutor(
                corePoolSize,
                maxPoolSize,
                keepAliveTime,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(queueCapacity),
                new ThreadPoolExecutor.CallerRunsPolicy()
        );

        MinioClient sourceClient = MinioClient.builder()
                .endpoint(sourceEndpoint)
                .credentials(sourceAccessKey, sourceSecretKey)
                .build();

        MinioClient targetClient = MinioClient.builder()
                .endpoint(targetEndpoint)
                .credentials(targetAccessKey, targetSecretKey)
                .build();

        ElasticsearchService elasticsearchService = new ElasticsearchService("esHost", 9200);

        // 用于记录成功同步的文件路径
        Set<String> successfulFiles = Collections.synchronizedSet(new HashSet<>());
        long totalBatchSize = 0;

        // 定时任务打印同步进度
        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(() -> {
            // 打印同步进度，包括跳过的文件个数
            System.out.println(String.format("Syncing progress: %d files synced, total size: %s, %d files skipped",
                    totalFilesSynced.get(), formatFileSize(totalSize.get()), skippedFilesCount.get()));
        }, 0, 10, TimeUnit.SECONDS); // 每10秒打印一次

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            List<String> batch = new ArrayList<>();
            String line;

            while ((line = reader.readLine()) != null) {
                batch.add(line);
                if (batch.size() == batchSize) {
                    List<String> batchToProcess = new ArrayList<>(batch);
                    executorService.submit(() -> processBatch(batchToProcess, sourceClient, targetClient, sourceBucket, targetBucket, successfulFiles, scheduler, elasticsearchService));
                    batch.clear();
                }
            }

            // 处理剩余的文件
            if (!batch.isEmpty()) {
                executorService.submit(() -> processBatch(batch, sourceClient, targetClient, sourceBucket, targetBucket, successfulFiles, scheduler, elasticsearchService));
            }
        }

        executorService.shutdown();
        executorService.awaitTermination(1, TimeUnit.HOURS);

        // 关闭定时任务
        scheduler.shutdown();
        // 关闭 Elasticsearch 客户端
        elasticsearchService.close();

        // 记录成功同步的文件路径到文件
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(successLogPath))) {
            for (String successFileName : successfulFiles) {
                writer.write(successFileName);
                writer.newLine();
            }
        }
    }

    private static void processBatch(List<String> batch, MinioClient sourceClient, MinioClient targetClient,
                                     String sourceBucket, String targetBucket, Set<String> successfulFiles,
                                     ScheduledExecutorService scheduler, ElasticsearchService elasticsearchService) {
        long batchStartTime = System.currentTimeMillis();
        int filesSynced = 0;
        long totalBatchSize = 0;

        // 用于存储要批量写入 Elasticsearch 的文件数据
        List<FileDataWarehouseIndex> fileDataList = new ArrayList<>();

        for (String filePath : batch) {
            long fileStartTime = System.currentTimeMillis();
            try (InputStream inputStream = sourceClient.getObject(GetObjectArgs.builder()
                    .bucket(sourceBucket)
                    .object(filePath)
                    .build())) {

                // 获取文件的大小
                long fileSize = inputStream.available();

                // 检查目标 MinIO 是否已存在该文件并且大小相同
                boolean fileExists = checkFileExists(targetClient, targetBucket, filePath, fileSize);

                if (!fileExists) {
                    // 将文件同步到目标 MinIO
                    targetClient.putObject(PutObjectArgs.builder()
                            .bucket(targetBucket)
                            .object(filePath)
                            .stream(inputStream, fileSize, -1)
                            .build());

                    // 记录成功同步的文件路径
                    successfulFiles.add(filePath);

                    // 更新统计
                    filesSynced++;
                    totalBatchSize += fileSize;
                    totalFilesSynced.incrementAndGet();
                    totalSize.addAndGet(fileSize);

                    // 创建 FileDataWarehouseIndex 对象并添加到 Elasticsearch 批量写入列表
                    FileDataWarehouseIndex fileData = FileDataWarehouseIndex.builder()
                            .fileName(filePath)
                            .fileSize(fileSize)
                            .fileType("unknown")  // 假设文件类型未知，需要根据实际情况设置
                            .fileDir(targetBucket)
                            .bucket(targetBucket)
                            .creator("system")  // 假设创建者为系统
                            .modifiedTime(System.currentTimeMillis())
                            .createTime(System.currentTimeMillis())
                            .build();
                    fileDataList.add(fileData);

                    // 打印日志：单个文件的同步情况
                    long fileSyncTime = System.currentTimeMillis() - fileStartTime;
                    System.out.println(String.format("File synced: %s (size: %s, time: %d ms)", filePath, formatFileSize(fileSize), fileSyncTime));
                } else {
                    // 如果文件已经存在并且大小相同，跳过该文件并更新跳过计数器
                    skippedFilesCount.incrementAndGet();
                    System.out.println(String.format("File already exists and is the same size: %s (size: %s), skipping...", filePath, formatFileSize(fileSize)));
                }
            } catch (MinioException | IOException e) {
                System.err.println("Error syncing file: " + filePath);
                e.printStackTrace();
            } catch (NoSuchAlgorithmException | InvalidKeyException e) {
                e.printStackTrace();
            }
        }

        // 批量写入 Elasticsearch
        try {
            if (!fileDataList.isEmpty()) {
                elasticsearchService.bulkIndexFiles(fileDataList);
            }
        } catch (IOException e) {
            System.err.println("Error indexing batch of files to Elasticsearch.");
            e.printStackTrace();
        }

        // 计算批次同步时间
        long batchSyncTime = System.currentTimeMillis() - batchStartTime;

        // 打印批次同步统计信息
        System.out.println(String.format("Batch synced: %d files (total size: %s) in %d ms", filesSynced, formatFileSize(totalBatchSize), batchSyncTime));
    }


    // 文件大小转换函数
    private static String formatFileSize(long size) {
        if (size <= 0) return "0 B";

        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int unitIndex = 0;
        double fileSize = size;

        while (fileSize >= 1024 && unitIndex < units.length - 1) {
            fileSize /= 1024;
            unitIndex++;
        }

        return String.format("%.2f %s", fileSize, units[unitIndex]);
    }

    // 检查目标 MinIO 中是否已存在该文件，并且大小是否相同
    private static boolean checkFileExists(MinioClient client, String bucket, String objectName, long expectedSize) {
        try {
            // 获取文件的元数据
            StatObjectArgs statObjectArgs = StatObjectArgs.builder()
                    .bucket(bucket)
                    .object(objectName)
                    .build();
            long remoteFileSize = client.statObject(statObjectArgs).size();

            // 如果远程文件存在且大小相同，则返回 true
            return remoteFileSize == expectedSize;
        } catch (MinioException | InvalidKeyException | IOException | NoSuchAlgorithmException e) {
            return false;
        }
    }
}
