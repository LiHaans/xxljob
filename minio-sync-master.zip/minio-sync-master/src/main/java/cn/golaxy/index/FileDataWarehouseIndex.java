package cn.golaxy.index;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.DigestUtils;

/**
 *  文件数仓索引实体
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileDataWarehouseIndex {


    private String modelName;

    private String modelNameReal;

    private String bucket;

    private String fileName;

    private Long fileSize;

    private String fileType;

    private String fileDir;

    private String creator;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Long modifiedTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Long createTime;


    // 获取主键
    public String key() {
        String key = bucket + "_" + fileDir + "_" + fileName;
        return DigestUtils.md5DigestAsHex(key.getBytes());
    }
}
