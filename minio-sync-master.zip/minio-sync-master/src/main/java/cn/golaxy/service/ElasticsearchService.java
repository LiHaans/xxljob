package cn.golaxy.service;

import cn.golaxy.index.FileDataWarehouseIndex;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.RestClient;
import org.apache.http.HttpHost;

import java.io.IOException;
import java.util.List;

public class ElasticsearchService {

    private final RestHighLevelClient client;

    public ElasticsearchService(String hostname, int port) {
        client = new RestHighLevelClient(
                RestClient.builder(new HttpHost(hostname, port, "http"))
        );
    }

    // 批量写入 Elasticsearch
    public void bulkIndexFiles(List<FileDataWarehouseIndex> fileDataList) throws IOException {
        BulkRequest bulkRequest = new BulkRequest();

        for (FileDataWarehouseIndex fileData : fileDataList) {
            bulkRequest.add(new IndexRequest("file_data_index")  // 替换为实际的索引名
                    .id(fileData.key())  // 使用 FileDataWarehouseIndex 的 key 作为文档 ID
                    .source(fileData));  // 使用 FileDataWarehouseIndex 的对象作为文档内容
        }

        // 执行批量请求
        BulkResponse bulkResponse = client.bulk(bulkRequest, RequestOptions.DEFAULT);

        if (bulkResponse.hasFailures()) {
            System.err.println("Some files failed to index");
        } else {
            System.out.println("Files successfully indexed.");
        }
    }

    public void close() throws IOException {
        client.close();
    }
}



