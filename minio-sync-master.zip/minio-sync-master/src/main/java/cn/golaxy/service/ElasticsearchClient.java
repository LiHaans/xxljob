package cn.golaxy.service;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;

public class ElasticsearchClient {

    private RestHighLevelClient client;

    public ElasticsearchClient() {
        this.client = new RestHighLevelClient(
                RestClient.builder(new HttpHost("localhost", 9200, "http")));
    }

    public RestHighLevelClient getClient() {
        return client;
    }

    public void close() throws Exception {
        if (client != null) {
            client.close();
        }
    }
}

